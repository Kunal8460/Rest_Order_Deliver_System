
/**
 * Restful services here
 */
package com.mycompany.preparationservice.service;